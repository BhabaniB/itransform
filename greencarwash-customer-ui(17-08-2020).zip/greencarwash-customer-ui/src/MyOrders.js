
import React,{Component} from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import  Axios from 'axios';
import {getUser} from './Utils/Common';
class MyOrders extends Component {
constructor(props){
    super(props);
    this.user=getUser()
    this.state={
        columnDefs: [{
            headerName: "Order ID", field: "orderid", sortable:true , filter:true, checkboxSelection: true
          },
          {
            headerName: "Provider", field: "serviceProvider", sortable:true , filter:true
          },
          {
            headerName: "Order Status", field: "orderStatus", sortable:true , filter:true
          }
          ,
          {
            headerName: "Reviews & Ratings", field: "reviewrating", sortable:true , filter:true
          }
          
        ],
          rowData: null,
          customer:this.user.username,
        }
    }


componentDidMount(){
    fetch('http://localhost:8084/myorders?customer='+this.state.customer)
      .then( response => response.json() ).then(rowData=>this.setState({rowData}))
    .catch(error => {
        console.log(error);
        // this.setState({error: true});
    }); 

}
onButtonClick1 = e => {
  const selectedNodes = this.gridApi.getSelectedNodes()
  const selectedData = selectedNodes.map( node => node.data)
  const data =selectedData.pop();
  Axios.get("http://localhost:8089/getreceipt?orderid="+ data.orderid)

  .then(response => {
    response.blob().then(blob => {
    window.URL.createObjectURL(blob);
     
    });
    
});
}
onButtonClick =(event) => { 
  const selectedNodes = this.gridApi.getSelectedNodes()
  const selectedData = selectedNodes.map( node => node.data)
  const data =selectedData.pop();
 let filePath="http://localhost:8089/getreceipt?orderid=";
  event.preventDefault(); window.open(filePath+data.orderid); }

  render() {
        return (
            <div
            className="ag-theme-alpine"
            style={{
            height: '150px',
            width: '820px' }}
          >
            <h2>MyOrders</h2>
        <AgGridReact
          onGridReady={ params => this.gridApi = params.api }
          columnDefs={this.state.columnDefs}
          rowData={(this.state.rowData)}>
        </AgGridReact>
        <tfoot>
   
   <button onClick={this.onButtonClick}>Download Bill</button>
   </tfoot>
        </div>

        );
        }
} export default MyOrders;