import React,{Component} from 'react';
import Axios from 'axios';


import { getUser } from './Utils/Common';
class WashOrder extends Component{
constructor(props){
super(props);
this.user=getUser() 
this.state={
customer:this.user.username,
car:'',
addon:'',
service:'',
servicetime:'',
serviceLocation:'',
note:'',
tax:'10',
orderStatus:'Inline',
services:[
/* { "id" :"1", "serviceName" : "Super Value", "serviceCost" : "2000", "serviceDesc" : "Car wash and polish" },
{ "id" : "2", "serviceName" : "Jumbo", "serviceCost" : "2200", "serviceDesc" : "Car wash, polish and oil change" },
{ "id" : "3", "serviceName" : "Megha Pack", "serviceCost" : "2500", "serviceDesc" : "Car wash, polish and oil change" } */
],
carList:[],
addOns:[]

    };
  } 

    dataHandler =()=>{
        const checkData = {
          customer:this.state.customer,
          car:this.state.car,
          addon:this.state.addon,
          service:this.state.service,
          servicetime:this.state.servicetime,
          serviceLocation:this.state.serviceLocation,
          note:this.state.note,
          tax:this.state.tax,
          orderStatus:this.state.orderStatus
        }
        const data={
          phone:this.user.username
        }
      
 Axios.post('http://localhost:8083/api/customer/viewcustomer',data)
 .then( response => { 
 console.log( response )     
 if(response.data!==''){
      Axios.post('http://localhost:8084/createorder', checkData)
      .then((res) => {
        console.log(res)
        sessionStorage.setItem('orderid',res.data.orderid)
        sessionStorage.setItem('amount', res.data.pay);
        this.setState({message :'Submitted Successfully'})
        this.props.history.push("/payment");
      }).catch((error) => {
        console.log(error)
      });

 }else{
 this.setState({message :'You are not registered user'})
 } } )
 .catch(error => {
          console.log(error);
          this.setState({message :'Something wrog to fetch details'})
  }); 
  }
  componentDidMount() {
    fetch('http://localhost:8085/api/data/serviceandprice')
    .then( response => response.json() )
    //.then(services=>this.setState({services}))
    .then(data => {
      let serviceFromApi = data.map(service => {
        return {value: service.serviceName+',Price:'+service.serviceCost, display: service.serviceName+',Price:'+service.serviceCost}
      });
      this.setState({
        services: [{value: '', display: ''}].concat(serviceFromApi)
      }); })
  .catch(error => {
      console.log(error);
      // this.setState({error: true});
  }); 

  fetch('http://localhost:8085/api/data/carlist')
  .then( response => response.json() )
 // .then(carList=>this.setState({carList}))
 .then(data => {
  let carsFromApi = data.map(car => {
    return {value: car.carBrand, display:car.carBrand}
  });
  this.setState({
    carList: [{value: '', display: ''}].concat(carsFromApi)
  } ); } )
.catch(error => {
    console.log(error);
    // this.setState({error: true});
});

fetch('http://localhost:8085/api/data/addonandprice')
  .then( response => response.json() )
  //.then(addOns=>this.setState({addOns}))
  .then(data => {
    let addoOnFromApi = data.map(addOn => {
      return {value: addOn.addOnName+',Price:'+addOn.addOnCost, display: addOn.addOnName+',Price:'+addOn.addOnCost}
    });
    this.setState({
      addOns: [{value: '', display: ''}].concat(addoOnFromApi)
    }); } )
.catch(error => {
    console.log(error);
    // this.setState({error: true});
});
   }
 
    
    render(){

    
        return(
<div >
<div>{this.state.message}</div>
      <table>
      <thead>
      <tr><td colSpan='2'>
      Wash Order
      </td></tr>  
     </thead>
      <tbody>
      <tr>
<td>Choose a car:</td><td> <select name="car" id="car" onChange={(event)=>this.setState({car:event.target.value})}>
{this.state.carList.map(car=>(<option key={car.value} value={car.value}>
  {car.value}
                </option>))}
</select>
</td>
</tr>
<tr>
<td>Service:</td><td> <select  name="service" id="service" onChange={(event)=>this.setState({service:event.target.value})}>
{this.state.services.map(service => (
            <option
              key={service.value}
              value={service.value}
            >
              {service.display}
            </option>
          ))}
              
             </select>
</td>
</tr>
<tr>
<td>Add On:</td><td> <select name="addon" id="addon" onChange={(event)=>this.setState({addon:event.target.value})}>
{/* {this.state.addOns.map(addOn=>(<option key={addOn.id} value={addOn.addOnName}>

   {addOn.addOnName}-{addOn.addOnCost}
</option>))
} */}
{this.state.addOns.map(addOn => (
            <option
              key={addOn.value}
              value={addOn.value}
            >
              {addOn.display}
            </option>
          ))}
</select>
</td>
</tr>
     <tr>
    <td>
    Service (date and time):
     </td>
     <td>
     <input type="datetime-local" id="servicetime" name="servicetime" onChange={(event)=>this.setState({servicetime:event.target.value})}/>
     </td>
     </tr>
    <tr>
    <td>
    Service Location:
     </td>
     <td>
    <textarea type='textarea' id='serviceLocation'name='serviceLocation' placeholder='Google Map' onChange={(event)=>this.setState({serviceLocation:event.target.value})}/>
     </td>
     </tr>
     <tr>
    <td>
     Note 
     </td>
     <td>
    <textarea type='textarea' id='note'name='note'  onChange={(event)=>this.setState({note:event.target.value})}/>
     </td>
     </tr>
     </tbody>
     <tfoot>
         <tr><td>
             <button  onClick={this.dataHandler}>Order</button></td>
         </tr>
     </tfoot>
     </table>
    
     </div>

        );
    }

}export default WashOrder;