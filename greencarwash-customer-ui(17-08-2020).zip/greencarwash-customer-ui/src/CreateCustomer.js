import React,{Component} from 'react';
import Axios from 'axios';

import { getUser } from './Utils/Common';

class CreateCustomer extends Component{
    constructor(props) {
        super(props);
        this.user=getUser()
          this.valid={
              validation:false
          }
          this.state = {
            phone: this.user.username,
            nameoncard:'',
            cardnumber:'',
            expirydate:'',
            cvv :'',
            car:'' 
           
          }
       
      };
cardDatValidator=()=>{
if(this.state.nameoncard!==''
&& this.state.cardnumber!==''
&& this.state.expirydate!==''
&& this.state.cvv!==''){
this.setState({message :'Validate Successfully'})
this.setState({cvv:''})
this.valid.validation=true
}
}

 postDataHandler =() =>{
if(this.valid.validation===true){
    const customer={
        phone: this.user.username,
        nameoncard:this.state.nameoncard,
        cardnumber:this.state.cardnumber,
        expirydate:this.state.expirydate,
        cvv :this.state.cvv,
        car:this.state.car
        
        }

        console.log(customer);
        Axios.post("http://localhost:8083/createcustomer",customer)
        .then( response => {
         console.log( response );
         this.setState({message :'Submitted Successfully'})
        /// this.props.history.push("/order");
        } ).catch(error => {
           this.setState({message:"Something went wrong. Please try again later."});
          } );
        
    }  
    }
    


render(){


return(
    

    <div >
  
<div>{this.state.message}</div>
     <table>
         <thead>
           <tr><td colSpan='2'>
               New Customer
           </td>
            </tr>  
         </thead>
     <tbody>
   
    <tr><td>Name On Card:</td><td>
    <input name='nameoncard' type='text' value={this.state.nameoncard} onChange={(event)=>this.setState({nameoncard:event.target.value})}/>
    </td></tr>
    <tr><td>Card Number:</td><td>
    <input name='cardnumber' type='text' value={this.state.cardnumber} onChange={(event)=>this.setState({cardnumber:event.target.value})}/>
    </td></tr>
    <tr><td>Expiry Date:</td><td>
    <input name='expirydate' type='text' value={this.state.expirydate} onChange={(event)=>this.setState({expirydate:event.target.value})}/>
    </td></tr>
    <tr><td>CVV:</td><td>
    <input name='cvv' type='password' value={this.state.cvv} onChange={(event)=>this.setState({cvv:event.target.value})}/>
    </td></tr>
    <tr><td>
        <button onClick={this.cardDatValidator} >Validate</button>
    </td>
        
        </tr>
<tr>
<td>Choose a car:</td><td> <select name="car" id="car" onChange={(event)=>this.setState({car:event.target.value})}>
  <option value=""></option>
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="mercedes">Mercedes</option>
  <option value="audi">Audi</option>
</select>
</td>
</tr>

    </tbody>
    <tfoot><tr><td>
        <button onClick={this.postDataHandler} >Submit</button>
    </td>
        
        </tr></tfoot>
    </table>
   
    </div>
 
)

} } export default CreateCustomer;