import React from 'react';
import { getUser, removeUserSession } from './Utils/Common';
import PrivateRoute from './Utils/PrivateRoute';
import { BrowserRouter, Switch, Route, NavLink } from 'react-router-dom';

import CreateCustomer from './CreateCustomer';
import WashOrder from './WashOrder';
import Payment from './Payment';
import MyOrders from './MyOrders';
import EditCustomer from './EditCustomer';


 
function Dashboard(props) {
  const user = getUser();
 
  // handle click event of logout button
  const handleLogout = () => {
    removeUserSession();
    props.history.push('/login');
  }
 
  return (
    <div>
      
      <input type="button" onClick={handleLogout} value="Logout" />
      Welcome {user.name}!<br /><br />
      <BrowserRouter>
          <div className="header">
          <NavLink exact activeClassName="active" to="/viewedit" >View/Edit Customer</NavLink>
          <NavLink activeClassName="active" to="/register" > Customer Registration</NavLink>
          <NavLink activeClassName="active" to="/order" > Wash Order</NavLink>
          <NavLink activeClassName="active" to="/payment">Payment</NavLink>
          <NavLink activeClassName="active" to="/myorders"> My Order</NavLink>
          </div>
          <div className="content">
          <Switch>
          <Route exact path="/viewedit" component={EditCustomer} />
          <PrivateRoute path="/register" component={CreateCustomer} />
          <PrivateRoute path="/order" component={WashOrder} />
          <PrivateRoute path="/payment" component={Payment}/>
          <PrivateRoute path="/myorders" component={MyOrders}/>
          </Switch>
          </div>
          </BrowserRouter>
    </div>
  );
}
 
export default Dashboard;