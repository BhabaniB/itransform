import React,{Component} from 'react';
import Axios from 'axios';

import {getUser} from './Utils/Common';
//import { CellPositionUtils } from 'ag-grid-community';

class EditCustomer extends Component{
 
    constructor(props) {
        super(props);
        this.user=getUser()
          this.valid={
              validation:false
          }
          this.state = {
            phone: this.user.username,
            nameoncard:'',
            cardnumber:'',
            expirydate:'',
            cvv :'',
            car:'' 
           
          }
       
      };

    componentDidMount(){
        const data={
            phone:this.state.phone
        }
        Axios.post('http://localhost:8083/api/customer/viewcustomer',
           data
        )
        .then( response => {
            console.log( response );
            this.setState(response.data);
            if(response.data!==""){
            this.setState({car:response.data.car}); 
        } else{
            this.setState({message :'You are not registered user'})
        }
        } )
        .catch(error => {
            console.log(error);
            // this.setState({error: true});
        }); 
        
    }
    
cardDatValidator=()=>{
    if(this.state.nameoncard!==''
    && this.state.cardnumber!==''
    && this.state.expirydate!==''
    && this.state.cvv!==''){
   // alert('Validate Successfully')
   this.setState({message :'Validate Successfully'})

    this.setState({cvv:''})
    this.valid.validation=true
    }
    }
    postDataHandler =() =>{
        if(this.valid.validation===true){
        const customer={
            phone: this.state.phone,
            nameoncard:this.state.nameoncard,
            cardnumber:this.state.cardnumber,
            expirydate:this.state.expirydate,
            cvv :this.state.cvv,
            car:this.state.car

                }
            Axios.post("http://localhost:8083/createcustomer",customer)
            .then( response => {
               
                console.log( response );
                this.setState({message :'Submitted Successfully'})
            } )
        }  
            
        }
render(){


return(
    <div>
        <div>{this.state.message}</div>
    <table>
        <thead>
          <tr><td colSpan='2'>
              Vew Customer
          </td>
           </tr>  
        </thead>
    <tbody>
  
   <tr><td>Name On Card:</td><td>
   <input name='nameoncard' type='text' value={this.state.nameoncard} onChange={(event)=>this.setState({nameoncard:event.target.value})}/>
   </td></tr>
   <tr><td>Card Number:</td><td>
   <input name='cardnumber' type='text' value={this.state.cardnumber} onChange={(event)=>this.setState({cardnumber:event.target.value})}/>
   </td></tr>
   <tr><td>Expiry Date:</td><td>
   <input name='expirydate' type='text' value={this.state.expirydate} onChange={(event)=>this.setState({expirydate:event.target.value})}/>
   </td></tr>
   <tr><td>CVV:</td><td>
   <input name='cvv' type='password' value={this.state.cvv} onChange={(event)=>this.setState({cvv:event.target.value})}/>
   </td></tr>
   <tr><td>
       <button onClick={this.cardDatValidator} >Validate</button>
   </td>
       
       </tr>
<tr>
<td>Choose a car:</td><td> <select name="car" id="car" value={this.state.car} onChange={(event)=>this.setState({car:event.target.value})}>
 <option value="volvo">Volvo</option>
 <option value="saab">Saab</option>
 <option value="mercedes">Mercedes</option>
 <option value="audi">Audi</option>
</select>
</td>
</tr>

   </tbody>
   <tfoot><tr><td>
       <button onClick={this.postDataHandler} >Submit</button>
   </td>
       
       </tr></tfoot>
   </table>
  
   </div>
 
)

} } export default EditCustomer;