import React,{Component} from 'react';
import Axios from 'axios';
import { getUser } from './Utils/Common';

class Payment extends Component{
user=getUser()
amount=sessionStorage.getItem('amount');
orderid=sessionStorage.getItem('orderid');
state={
    customer: this.user.username,
    orderid:this.orderid,
    amount:this.amount
    }
    componentDidMount(){
        const data={
            phone:this.state.customer
        }
        Axios.post('http://localhost:8083/api/customer/viewcustomer',
           data
        )
        .then( response => {
           // console.log( response );
            this.setState(response.data);
        } )
        .catch(error => {
            //console.log(error);
            // this.setState({error: true});
        }); 
         
       
    }

    postDataHandler =() =>{

        const pay={
             
            orderid: this.state.orderid,
            customer:this.state.customer,
            amountpaid:this.state.amount
       }
       Axios.post('http://localhost:8084/api/serviceorder/payment',pay)
       .then( response => {
                console.log( response );
                this.setState({successmsg:'Payment Successful'})
            } )  
        }
render(){


return(
    <div >
        <div>{this.state.successmsg}</div>
        <br/>
        <div>Payment</div>
        <br/>
    <table>
        
    <tbody>
    <tr><td>Amount</td><td>
      {this.state.amount}
   </td>
       
       </tr>
   <tr><td>Name On Card:</td><td>
   <input name='nameoncard' type='text' value={this.state.nameoncard} onChange={(event)=>this.setState({nameoncard:event.target.value})}/>
   </td></tr>
   <tr><td>Card Number:</td><td>
   <input name='cardnumber' type='text' value={this.state.cardnumber} onChange={(event)=>this.setState({cardnumber:event.target.value})}/>
   </td></tr>
   <tr><td>Expiry Date:</td><td>
   <input name='expirydate' type='text' value={this.state.expirydate} onChange={(event)=>this.setState({expirydate:event.target.value})}/>
   </td></tr>
   <tr><td>CVV:</td><td>
   <input name='cvv' type='password' value={this.state.cvv} onChange={(event)=>this.setState({cvv:event.target.value})}/>
   </td></tr>
   


   </tbody>
   <tfoot><tr><td>
       <button onClick={this.postDataHandler} >Payment</button>
   </td>
       
       </tr></tfoot>
   </table>
  
   </div>
 
)

} } export default Payment;