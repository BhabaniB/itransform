import React from 'react';
 
function Home() {
  return (
    <div>
      Welcome to the Green Car Wash Service!
    </div>
  );
}
 
export default Home;